document.addEventListener("DOMContentLoaded", () => {
    const mapContainer = document.getElementById("map");
    if (!mapContainer) return;

    // SVG уже вставлен прямо в HTML, поэтому просто ищем области внутри #map
    let regionsArray = Array.from(document.querySelectorAll("#map [id^='UA-']"));

    // Всі області
    const kievCity = document.getElementById("KyivCity");
    const sevastopolCity = document.getElementById("SevastopolCity");

    if (kievCity) regionsArray.push(kievCity);
    if (sevastopolCity) regionsArray.push(sevastopolCity);

    const containers = document.querySelectorAll(".regionInfo");
    const noRegion = document.getElementById("noRegion");
    let pinnedId = null; // ID області, яка вибрана кліком

    // Показ інформації про область
    function showInfo(id, shouldPin = false) {
        let infoId = id;

        // костиль з городом київ і городом севастополь
        if (id === "KyivCity") infoId = "UA-30";
        if (id === "SevastopolCity") infoId = "UA-43";

        // прячемо інформацію про області
        containers.forEach(cont => cont.classList.remove("active"));

        const target = document.getElementById("cont" + infoId);
        if (target) target.classList.add("active");

        // обрали область
        if (shouldPin) {
            regionsArray.forEach(r => r.classList.remove("active-region"));
            const targetRegion = document.getElementById(id);
            if (targetRegion) targetRegion.classList.add("active-region");
        }
    }

    // Мапа
    regionsArray.forEach(region => {
        region.addEventListener("mouseenter", () => {
            // Коли обрана область інформація залишається
            if (!pinnedId) {
                showInfo(region.id, false);
                if (noRegion) noRegion.style.display = "none";
            }
        });

        // Обрати область
        region.addEventListener("click", (e) => {
            e.stopPropagation(); // Зупиняємо подію, щоб не спрацював клік по документу
            pinnedId = region.id;
            showInfo(pinnedId, true);
            if (noRegion) noRegion.style.display = "none";
        });
    });

    // Прибрали мишу з карти
    mapContainer.addEventListener("mouseleave", () => {
        if (!pinnedId) {
            // Пустий бокс з інформацією виберіть область
            if (noRegion) noRegion.style.display = "block";
            containers.forEach(cont => cont.classList.remove("active"));
            regionsArray.forEach(r => r.classList.remove("active-region"));
        }
    });

    // Перевірка на клік
    document.addEventListener("click", (e) => {
        const modal = document.getElementById("imageModal");
        const modalImg = document.getElementById("fullImage");

        // Збільшення картинки
        if (e.target.closest(".regionInfo img")) {
            if (modal && modalImg) {
                modal.style.display = "block";
                modalImg.src = e.target.src;
                document.body.style.overflow = "hidden";
            }
            return;
        }

        // Кнопка закрити вікно з картинкою
        if (e.target.classList.contains("close-modal") || e.target === modal) {
            if (modal) {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }
            return;
        }

        // Вибрати область
        if (e.target.closest("#map")) return;

        // Прибрати вибирання області
        if (!e.target.closest(".regionInfo")) {
            if (noRegion) noRegion.style.display = "block";
            pinnedId = null;
            containers.forEach(cont => cont.classList.remove("active"));
            regionsArray.forEach(r => r.classList.remove("active-region"));
        }
    });

    // Зменшити картинку
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            const modal = document.getElementById("imageModal");
            if (modal) {
                modal.style.display = "none";
                document.body.style.overflow = "auto";
            }
        }
    });
});