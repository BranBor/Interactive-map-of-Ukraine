# Корисні копалини України

An informational website about the natural mineral resources of Ukraine — an interactive SVG map of every oblast with a price/resource breakdown, a reference guide to mineral types, and a photo gallery. Content is in Ukrainian. Fully static, no backend or build step required.

## Features

- **Interactive map** (`map.html`) — a clickable SVG map of Ukraine's regions (oblasts + Kyiv City + Sevastopol/Crimea). Hover or click a region to see its estimated mineral wealth and a short description; click a region's image to view it full-screen.
- **Reference guide** (`knowledge.html`) — a jump-nav guide explaining categories of minerals (fuel resources, metals, gemstones, building materials, etc.), plus a link to the official geological survey map.
- **Gallery** (`gallery.html`) — supporting maps and images.
- **Responsive design** — separate stylesheets are loaded per breakpoint (mobile / laptop / monitor) via `<link media="...">`.

## Tech stack

- HTML5 + CSS3 (flexbox layouts, responsive breakpoints)
- Vanilla JavaScript (region hover/click state, image lightbox modal)
- Inline SVG map (originally created with the [MapSVG](http://mapsvg.com) plugin)
- Google Fonts / system font stack

No server-side language, database, or build step — everything runs in the browser.

## Project structure

```
.
├── index.html            # landing page
├── map.html               # interactive resource map
├── knowledge.html          # mineral reference guide
├── gallery.html            # image gallery
├── about.html               # about the project
├── css/
│   ├── style.css           # base styles (all breakpoints)
│   ├── mobile.css          # ≤600px
│   ├── laptop.css          # 601–1280px
│   └── monitor.css         # ≥1281px
├── script/
│   └── script.js           # map interactivity, modal lightbox
├── images/
│   ├── minerals/            # per-region images shown in the map info panel
│   └── dovidkaImages/        # reference-guide illustrations
├── .gitignore
├── .gitattributes
├── LICENSE
└── README.md
```

## Getting started

This is a static site — no PHP, no database, no build tooling. You can open `index.html` directly in a browser, or serve it locally with any static file server:

- **Python 3**: `python3 -m http.server 8000` from the project root, then open `http://localhost:8000/index.html`.
- **Node.js**: `npx serve .` from the project root.
- **VS Code**: install the "Live Server" extension and open `index.html` with it.

## Known limitations

- **Image assets aren't included in this repo.** The `images/minerals/` and `images/dovidkaImages/` folders are present but empty (with `.gitkeep` placeholders) — you'll need to add the referenced images (region illustrations, reference-guide screenshots, gallery photos) before the site will render fully.
- Mineral value figures shown on the map are illustrative/approximate, not sourced from a live dataset.

## License

MIT — see [LICENSE](LICENSE).
